import re


class InterpreterAgent:
    """
    Rule-based intent interpreter.

    Builds a structured intent dict from the user query using keyword matching
    and the semantic_map supplied at setup time.

    Confidence rules
    ----------------
    - 0.9  → matched a strong analytical keyword; skip LLM
    - 0.2  → no recognisable keyword; defer to LLM
    """

    METRIC_SYNONYMS = {
        "sales",
        "revenue",
        "profit",
        "spend",
        "spending",
        "spent",
        "cost",
        "costs",
        "amount",
        "amounts",
        "value",
        "values",
        "earning",
        "earnings",
        "income",
        "price",
        "prices",
    }

    @staticmethod
    def _should_count(query: str, columns: list) -> bool:
        """
        Returns True if "most/least/highest/lowest" in the query refers to
        counting entities (patients, airports) rather than summing a metric.

        Logic: if the word after most/least is not a known column or metric
        synonym → user is counting rows, not summing a value.
        """
        q = query.lower()
        col_set = set(columns)
        METRIC_SYNONYMS = {
            "sales",
            "revenue",
            "profit",
            "spend",
            "spending",
            "spent",
            "cost",
            "costs",
            "amount",
            "amounts",
            "value",
            "values",
            "earning",
            "earnings",
            "income",
            "price",
            "prices",
        }
        m = re.search(r"\b(?:most|least|highest|lowest)\s+(\w+)", q)
        if m:
            word_after = m.group(1)
            if word_after in col_set or word_after in METRIC_SYNONYMS:
                return False
            return True
        # "most/least" at end of query → count
        if re.search(r"\b(?:most|least)\s*[?]?$", q.strip()):
            return True
        return False

    STRONG_KEYWORDS = {
        "highest",
        "lowest",
        "top",
        "bottom",
        "average",
        "avg",
        "mean",
        "trend",
        "over time",
        "monthly",
        "daily",
        "weekly",
        "yearly",
        "total",
        "sum",
        "most",
        "least",
        "max",
        "min",
        "distribution",
        "breakdown",
        "compare",
        "which",
        "what",
        "when",
        # Display / grouping words — common in natural phrasing
        "show",
        "show me",
        "give me",
        "list",
        "get",
        "find",
        "by",
        "per",
        "across",
        "grouped",
        "group",
        # Sort order
        "ascending",
        "descending",
        "asc",
        "desc",
        "increasing",
        "decreasing",
        "sorted",
        "order",
        # Count / frequency
        "count",
        "how many",
        "number of",
        "frequency",
        "occurrences",
        "tally",
        "total number",
    }

    # Order matters: first match wins.
    QUERY_TYPE_MAP = [
        ("top", "top_n", "sum"),
        ("bottom", "top_n", "sum"),
        ("highest", "comparison", "sum"),
        ("lowest", "comparison", "sum"),
        ("most", "comparison", "sum"),
        ("least", "comparison", "sum"),
        ("average", "aggregation", "mean"),
        ("avg", "aggregation", "mean"),
        ("mean", "aggregation", "mean"),
        ("trend", "trend", "sum"),
        ("over time", "trend", "sum"),
        ("monthly", "trend", "sum"),
        ("daily", "trend", "sum"),
        ("total", "aggregation", "sum"),
        ("sum", "aggregation", "sum"),
        ("distribution", "aggregation", "sum"),
        ("breakdown", "aggregation", "sum"),
        ("compare", "comparison", "sum"),
        ("max", "comparison", "sum"),
        ("min", "comparison", "sum"),
        ("weekly", "trend", "sum"),
        ("yearly", "trend", "sum"),
        ("which", "comparison", "sum"),
        ("when", "trend", "sum"),
        # Count query type
        ("how many", "count", "count"),
        ("number of", "count", "count"),
        ("count", "count", "count"),
        ("frequency", "count", "count"),
        ("tally", "count", "count"),
    ]

    # Natural-language synonyms that mean "use the configured metric".
    # When a user says "top 5 items by SALES", "sales" isn't a column —
    # it's a synonym for whatever metric they configured.
    METRIC_SYNONYMS = {
        "sales",
        "revenue",
        "profit",
        "spend",
        "spending",
        "spent",
        "cost",
        "costs",
        "amount",
        "amounts",
        "value",
        "values",
        "earning",
        "earnings",
        "income",
        "price",
        "prices",
    }

    # Domain-specific dimension keyword map — intentionally minimal.
    # We rely on column-name matching instead of hardcoded domain words
    # so QueryMind works on ANY dataset (airports, healthcare, sports etc.)
    # Only add here if a word reliably maps to a column name across ALL domains.
    DIMENSION_KEYWORDS = {}

    # Time-related words that should route dimension → time column
    TIME_WORDS = {
        "month",
        "monthly",
        "year",
        "yearly",
        "annual",
        "week",
        "weekly",
        "daily",
        "day",
        "date",
        "over time",
        "when",
    }

    def run(self, context):
        query = context["user_query"].lower().strip()
        schema = context["schema"]["columns"]
        semantic_map = context["semantic_map"]

        columns = [col["name"] for col in schema]

        # Internal/system columns that must never appear in intent
        # (defined early so validation below can reference it)
        INTERNAL_COLS = {"_sheet"}

        # Validate semantic_map columns exist in the dataframe and are not internal
        default_metric = semantic_map.get("metric")
        default_dimension = semantic_map.get("dimension")

        if default_metric not in columns or default_metric in INTERNAL_COLS:
            default_metric = None
        if default_dimension not in columns or default_dimension in INTERNAL_COLS:
            # Pick the first real categorical column as fallback
            default_dimension = next(
                (
                    c
                    for c in columns
                    if c not in INTERNAL_COLS
                    and not any(h in c for h in {"id", "row_id", "index", "key"})
                ),
                None,
            )

        # Guard: empty / numeric-only
        if not query or query.isdigit():
            context["error"] = "Please enter a meaningful question."
            return context

        # ── Base intent ──────────────────────────────────────────────────
        intent = {
            "metric": default_metric,
            "dimension": default_dimension,
            "query_type": "aggregation",
            "operation": "sum",
            "limit": None,
        }

        # ── Metric resolution ────────────────────────────────────────────
        # (INTERNAL_COLS defined above at validation step)

        # Build a lookup of actual column dtypes from the schema so we can
        # check "is this column numeric?" using REAL data, not hardcoded
        # domain words like "sales"/"revenue" (which broke on sports/health data).
        col_types = {c["name"]: c.get("type", "") for c in schema}
        NUMERIC_DTYPES = ("int", "float", "Int", "Float")

        def _is_numeric_col(col_name: str) -> bool:
            dtype = col_types.get(col_name, "")
            return any(dtype.startswith(p) for p in NUMERIC_DTYPES)

        id_hints = {"id", "_id", "row_id", "index", "key", "code"}

        def _is_id_col(col_name: str) -> bool:
            return any(h in col_name.lower() for h in id_hints)

        # 1. If an exact column name appears in the query → use it as metric,
        #    as long as the column is actually numeric AND not an ID column.
        #    This works for ANY domain (sales, sports, healthcare) because it
        #    checks real dtype, not a hardcoded word list.
        metric_found = False
        matched_cols = []  # collect all column matches for tie-breaking
        query_words = set(query.split())
        for col in columns:
            if col in INTERNAL_COLS:
                continue
            readable = col.replace("_", " ").strip()
            if not readable:
                continue
            # Full match: exact column name or full readable form in query
            full_match = col in query or readable in query
            # Partial match: any individual word of the column name appears
            # as a standalone word in the query (e.g. "goals" matches "goals_scored")
            col_words = set(readable.split())
            partial_match = bool(col_words & query_words) and len(col_words) > 0
            # Only count partial matches for multi-word columns, to avoid
            # single short words like "id" matching everything
            if full_match or (partial_match and len(col) > 4):
                matched_cols.append(col)

        # Prefer the longest match (most specific) among numeric, non-ID columns
        numeric_matches = [
            c for c in matched_cols if _is_numeric_col(c) and not _is_id_col(c)
        ]
        if numeric_matches:
            intent["metric"] = max(numeric_matches, key=len)
            metric_found = True

        # 2. If a metric synonym appears, keep the configured default metric
        #    (don't override — the synonym just confirms "use the metric column")
        if not metric_found:
            for syn in self.METRIC_SYNONYMS:
                if syn in query:
                    intent["metric"] = default_metric  # keep semantic default
                    break

        # ── Dimension resolution ─────────────────────────────────────────
        # 1. Keyword → dimension map (explicit, fast)
        dim_set = False
        for keyword, col_name in self.DIMENSION_KEYWORDS.items():
            if keyword in query and col_name in columns:
                intent["dimension"] = col_name
                dim_set = True
                break

        # 2. Exact column name match (catches user's own column names)
        if not dim_set:
            for col in columns:
                if col in INTERNAL_COLS:
                    continue
                readable = col.replace("_", " ").strip()
                if not readable:
                    continue
                if col in query or readable in query:
                    if col != intent.get("metric"):  # don't use metric as dimension
                        intent["dimension"] = col
                        break

        # 3. Time-column override for trend queries (handled below after query type)

        # ── Query-type detection ─────────────────────────────────────────
        matched_type = None
        matched_op = None

        for keyword, q_type, op in self.QUERY_TYPE_MAP:
            if keyword in query:
                matched_type = q_type
                matched_op = op
                break

        if matched_type:
            intent["query_type"] = matched_type
            intent["operation"] = matched_op

        # ── Count override: "most/least/which <non-column noun>" → count ─────
        # e.g. "most patients by blood_type" → COUNT not SUM
        # Detect: comparison query where subject word is not a column name
        if intent["query_type"] in ("comparison", "top_n"):
            count_triggers = {"most", "least", "which", "how", "many", "number"}
            words = query.split()
            for i, w in enumerate(words):
                if w in count_triggers and i + 1 < len(words):
                    next_word = words[i + 1].strip("?.,")
                    # If next word is not a column and not a stop word → count
                    col_parts = {p for c in columns for p in c.split("_")}
                    stops = {
                        "in",
                        "by",
                        "per",
                        "of",
                        "the",
                        "a",
                        "an",
                        "is",
                        "are",
                        "was",
                        "were",
                        "has",
                        "have",
                        "from",
                        "for",
                        "with",
                        "and",
                        "or",
                    }
                    if (
                        next_word not in col_parts
                        and next_word not in stops
                        and next_word not in columns
                        and next_word not in {c.replace("_", "") for c in columns}
                        and len(next_word) > 2
                    ):
                        intent["query_type"] = "count"
                        intent["operation"] = "count"
                        break

        # ── top-N: extract explicit number ───────────────────────────────
        if intent["query_type"] == "top_n":
            m = re.search(r"(?:top|bottom)\s+(\d+)", query)
            intent["limit"] = int(m.group(1)) if m else 5
            if "bottom" in query:
                intent["ascending"] = True

        # ── Time-word detection + granularity ───────────────────────────
        # "which month gave max sales?" → trend grouped by month, not by day.
        # Detect granularity first, then override query_type to trend.
        time_col = semantic_map.get("time")
        has_time_word = any(tw in query for tw in self.TIME_WORDS)

        # Granularity: what period to group by
        if "year" in query or "annual" in query or "yearly" in query:
            intent["time_granularity"] = "year"
        elif "month" in query or "monthly" in query:
            intent["time_granularity"] = "month"
        elif "week" in query or "weekly" in query:
            intent["time_granularity"] = "week"
        else:
            intent["time_granularity"] = "day"  # default: daily

        if has_time_word:
            if time_col and time_col in columns:
                # Time column configured → route to trend
                intent["query_type"] = "trend"
                intent["dimension"] = time_col
            else:
                # No time column configured → flag the error so pipeline
                # can reject cleanly instead of running a bogus trend query
                intent["no_time_column"] = True

        # ── trend: always ensure dimension is time column ─────────────────
        if intent["query_type"] == "trend":
            if time_col and time_col in columns:
                intent["dimension"] = time_col
            elif not intent.get("no_time_column"):
                intent["no_time_column"] = True

        # ── Sort order + focus detection ──────────────────────────────────
        # Two separate concepts:
        # - sort_ascending: how to ORDER the table (asc or desc)
        # - focus_min:      which END to HIGHLIGHT in the insight text
        #
        # "lowest sales in descending order" →
        #     sort_ascending=False (table high→low), focus_min=True (highlight South)
        # "highest sales in ascending order" →
        #     sort_ascending=True  (table low→high), focus_min=False (highlight East)

        ASC_PHRASES = {
            "ascending order",
            "ascending",
            "asc order",
            "asc",
            "lowest to highest",
            "low to high",
            "smallest to largest",
            "increasing order",
            "increasing",
            "worst to best",
            "least to most",
        }
        DESC_PHRASES = {
            "descending order",
            "descending",
            "desc order",
            "desc",
            "highest to lowest",
            "high to low",
            "largest to smallest",
            "decreasing order",
            "decreasing",
            "best to worst",
            "most to least",
        }
        MIN_WORDS = {
            "minimum",
            "min",
            "less",
            "least",
            "lowest",
            "worst",
            "bottom",
            "fewest",
            "smallest",
        }
        MAX_WORDS = {
            "maximum",
            "max",
            "most",
            "highest",
            "greatest",
            "best",
            "top",
            "largest",
            "biggest",
        }

        explicit_asc = any(p in query for p in ASC_PHRASES)
        explicit_desc = any(p in query for p in DESC_PHRASES)
        implicit_min = any(w in query for w in MIN_WORDS)
        implicit_max = any(w in query for w in MAX_WORDS)

        # Sort order: explicit phrase wins; implicit min → asc; default → desc
        if explicit_asc and not explicit_desc:
            intent["ascending"] = True
        elif explicit_desc and not explicit_asc:
            intent["ascending"] = False
        elif implicit_min and not implicit_max:
            intent["ascending"] = True
        # else: default False (descending) already set

        # Focus: driven only by min/max intent words, not sort phrase
        if implicit_min and not implicit_max:
            intent["focus_min"] = True
        else:
            intent["focus_min"] = False

        # ── Sheet scope ──────────────────────────────────────────────────
        # Detect "in sheet Orders", "from Returns sheet", "across all sheets"
        available_sheets = context.get("excel_sheets", [])
        if available_sheets:
            scope = _detect_sheet_scope(query, available_sheets)

            # Nonexistent sheet → error immediately, don't silently fall back
            if isinstance(scope, tuple) and scope[0] == _SHEET_NOT_FOUND:
                _, mentioned = scope
                context["error"] = (
                    f"❌ Sheet '{mentioned}' is not loaded.\n"
                    f"  Loaded sheets: {available_sheets}\n\n"
                    f"  Try one of the loaded sheets, or re-run QueryMind "
                    f"and select '{mentioned}' if it exists in your file."
                )
                return context

            intent["sheet"] = scope

            # ── Sheet-aware dimension fallback ────────────────────────────
            # If a specific sheet is scoped AND no explicit dimension was
            # found in the query, pick the first valid categorical column
            # from THAT sheet rather than using the global semantic default.
            # This prevents "_sheet" or a cross-sheet column from leaking in.
            if (
                scope
                and not isinstance(scope, tuple)
                and (
                    intent["dimension"] == default_dimension
                    or intent["dimension"] in INTERNAL_COLS
                    or intent["dimension"] is None
                )
            ):
                sheet_df = context.get("sheet_dataframes", {}).get(scope)
                if sheet_df is not None:
                    # Find first non-internal, non-numeric, non-id column
                    id_hints = {"id", "key", "index", "row", "num", "code"}
                    sheet_categoricals = [
                        c
                        for c in sheet_df.columns
                        if c not in INTERNAL_COLS
                        and c != intent.get("metric")
                        and not any(h in c.lower() for h in id_hints)
                        and str(sheet_df[c].dtype) in ("object", "str", "string")
                        and "datetime" not in str(sheet_df[c].dtype)
                    ]
                    if sheet_categoricals:
                        intent["dimension"] = sheet_categoricals[0]

        # ── Confidence ───────────────────────────────────────────────────
        has_strong = any(kw in query for kw in self.STRONG_KEYWORDS)

        # Sheet name mention in query is a strong signal of analytical intent
        sheet_mentioned = any(
            s.lower() in query for s in context.get("excel_sheets", [])
        )

        # Column name mention is also a strong signal
        col_mentioned = any(
            col.replace("_", " ") in query or col in query for col in columns
        )

        context["intent_confidence"] = (
            0.9 if (has_strong or sheet_mentioned or col_mentioned) else 0.2
        )

        context["intent"] = intent
        return context


# ── Sheet-scope detection (appended at module level, called inside run) ──────
# This is a standalone helper imported by InterpreterAgent.run()
# It detects patterns like:
#   "top 5 sales in sheet Orders"
#   "average profit from the Returns sheet"
#   "across all sheets"

import re as _re

# Sentinel returned when user mentioned a sheet name that doesn't exist
_SHEET_NOT_FOUND = "__SHEET_NOT_FOUND__"


def _detect_sheet_scope(query: str, available_sheets: list):
    """
    Returns:
      - sheet name (str)  → user referenced a loaded sheet
      - None              → use combined df (all sheets / no sheet mentioned)
      - _SHEET_NOT_FOUND  → user mentioned "sheet X" but X isn't loaded
    """
    q = query.lower()

    # "across all sheets" / "all sheets" / "every sheet" → None (use combined df)
    if any(p in q for p in ["all sheets", "across sheets", "every sheet", "all data"]):
        return None

    # Match a loaded sheet name
    for sheet in available_sheets:
        if sheet.lower() in q:
            return sheet

    # Detect "sheet <word>" pattern where <word> didn't match any loaded sheet
    sheet_ref = _re.search(
        r"(?:in|from|on|the|of)?\s*sheet\s+([\w\s]+?)(?:\s+sheet)?(?:$|\s+by|\s+in|\s+with|\s+for)",
        q,
    )
    if sheet_ref:
        mentioned = sheet_ref.group(1).strip().title()
        return _SHEET_NOT_FOUND, mentioned  # return tuple: sentinel + what user typed

    return None
