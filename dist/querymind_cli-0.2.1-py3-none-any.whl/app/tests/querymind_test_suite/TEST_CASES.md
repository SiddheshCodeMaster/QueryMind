# QueryMind Regression Test Suite

29 synthetic files covering every connector (CSV, JSON, JSONL, XLSX, XLS) and every bug fixed to date. Run through this checklist after any pipeline change before releasing.

---

## CSV — Core domains

### `sales.csv` (500 rows) — baseline regression
| Query | Expected |
|---|---|
| `top 5 regions by sales` | Bar chart, descending, $ formatting |
| `lowest sales by region` | Ascending focus, correct min highlighted |
| `lowest sales in descending order` | Table desc, insight still names the min |
| `average sales by payment_method` | Mean aggregation, $ formatting |
| `sales trend over time monthly` | Grouped by month, chronological order |

### `healthcare.csv` (800 rows) — no currency metric, count-heavy
| Query | Expected |
|---|---|
| `most patients in blood_type` | **COUNT** query, plain integers, no $ |
| `which hospital has the most patients` | COUNT, hospital with highest patient count |
| `average age by hospital` | Mean of age, plain number, no $ |
| `how many patients by insurance_provider` | COUNT, no $ |

### `sports.csv` (300 rows) — different vocabulary
| Query | Expected |
|---|---|
| `top 5 players by goals_scored` | Works without any sales-domain hardcoding |
| `which team has the most goals` | Comparison, sums goals_scored (real column) |
| `average matches_played by position` | Mean aggregation |

### `customers_ids.csv` (200 rows) — int display regression
| Query | Expected |
|---|---|
| `top 5 customer_id by sales` | **customer_id shows as `553` not `553.0`** |

---

## CSV — Edge cases

| File | Query | Expected |
|---|---|---|
| `headers_only.csv` | any query | Clean error: empty file, not a crash |
| `single_column.csv` | any query | Error: needs ≥2 columns, no infinite prompt loop |
| `duplicate_columns.csv` | `show columns` | Warning shown, duplicates deduplicated, no `AttributeError` |
| `identical_dimension.csv` | `top sales by region` | No crash on single unique dimension value |
| `packed_dates.csv` | `sales trend by ship_date` | Packed ints (e.g. `1032024`) parsed as dates correctly |
| `messy_currency.csv` | `total sales by region` | `$1,234.56` strings coerced to numeric |
| `high_nulls.csv` (40% null) | `average sales by region` | Nulls excluded from mean, no crash |
| `negative_values.csv` | `lowest profit by department` | Negative values handled, correct min |
| `bom_encoded.csv` | load only | BOM stripped, loads cleanly |
| `semicolon_delimited.csv` | load only | Delimiter auto-detected as `;` |
| `completely_empty.csv` (0 bytes) | load only | Clean error, not `EmptyDataError` traceback |

---

## JSON

| File | Structure | Query | Expected |
|---|---|---|---|
| `airports_flat.json` | Flat array | `how many airports by country` | COUNT query works, no missing-column error on "airports" |
| `airports_wrapped.json` | Nested under `data` key | load only | Auto-selects `data` key (only 1 array key), prints confirmation |
| `multi_key.json` | 2 array keys (`airports`, `airlines`) | load only | **Interactive prompt** — user must choose which key |
| `healthcare_nested.json` | Nested `details` object | `average age by details_hospital` | `json_normalize` flattens `details.hospital` → `details_hospital` |
| `empty_array.json` | `[]` | load only | Clean error: "JSON file is empty" |
| `invalid.json` | Malformed syntax | load only | Clean error: "Invalid JSON file", not raw traceback |

---

## JSONL

| File | Query | Expected |
|---|---|---|
| `sales.jsonl` (100 lines) | `top 5 regions by sales` | Loads via `pd.read_json(lines=True)`, same results as sales.csv |
| `sports.jsonl` (50 lines) | `which team has most goals` | Works identically to sports.csv |

---

## XLSX — Multi-sheet

### `multi_sheet.xlsx` (Orders 400 rows / Returns 60 rows / Users 4 rows)
| Query | Expected |
|---|---|
| `show sales in sheet Orders by region` | Sheet-scoped, dimension auto-resolved (not `_sheet`) |
| `which manager had the most sales` | **Cross-sheet JOIN** — Orders ⋈ Users on `region` |
| `top 5 by status in Returns` | Clean error: Returns has no numeric metric, suggests Orders |
| `sales by region` (no sheet specified) | Uses combined df correctly |

### `multiword_sheets.xlsx` ("List of Orders" / "Return Records")
| Query | Expected |
|---|---|
| `show sales in sheet List of Orders by region` | Multi-word sheet name parsed correctly, no false "missing column" on "orders" |
| `highest sales in sheet Inventory` | Clean error: sheet "Inventory" not loaded (doesn't exist) |

### `single_sheet.xlsx` (healthcare data, 300 rows)
| Query | Expected |
|---|---|
| `most patients in blood_type` | Single-sheet Excel behaves identically to CSV |

### `lookup_only.xlsx` (Countries — no numeric columns)
| Query | Expected |
|---|---|
| `top 5 by country_name` | Clean error: no numeric columns, this looks like a lookup table |
| `how many countries` | COUNT still works — doesn't need a numeric metric |

---

## XLS (legacy format)

### `legacy.xls` (sports data, 150 rows)
| Query | Expected |
|---|---|
| `top 5 players by goals_scored` | Loads via `xlrd` engine, identical results to .xlsx version |

---

## Cross-cutting checks (run on ANY file)

- [ ] `/profile` — shows correct row/column counts, null %, type classification
- [ ] `/history` — shows last 5 queries, file path is correct
- [ ] Session file (`~/querymind_sessions/querymind_history.md`) — entry appended after every query
- [ ] `exit` / `quit` — session closes cleanly, footer written
- [ ] Gibberish query (`asdfgh`) — rejected by InputGuard, helpful suggestions shown
- [ ] Sort order — `ascending`/`descending`/`asc`/`desc` keywords don't get flagged as missing columns
- [ ] Ollama unavailable — clean fallback message, no crash

---

## How to run

```bash
querymind
# Load each file above, run the listed queries, confirm expected output
```

For automated regression testing later, each row in this table can become a pytest case once the pipeline is refactored to accept query+file as a single function call.
